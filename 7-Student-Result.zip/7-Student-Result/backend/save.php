<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$conn = mysqli_connect("localhost", "root", "", "vit_result");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data)) {

    $name = $data['name'];
    $course = $data['course'];
    $s1 = $data['sub1'];
    $s2 = $data['sub2'];
    $s3 = $data['sub3'];
    $s4 = $data['sub4'];

    $sql = "INSERT INTO students(name,course,sub1,sub2,sub3,sub4)
            VALUES('$name','$course','$s1','$s2','$s3','$s4')";

    mysqli_query($conn, $sql);

    echo "Saved";
}
?>