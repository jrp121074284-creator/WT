function Student(props) {
  return (
    <div>
      <h3>Student Info</h3>
      <p>Name: {props.data.name}</p>
      <p>Course: {props.data.course}</p>
    </div>
  );
}

export default Student;