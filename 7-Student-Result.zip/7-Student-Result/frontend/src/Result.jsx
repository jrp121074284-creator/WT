function Result(props) {

  const { sub1, sub2, sub3, sub4 } = props.marks;

  const total =
    Number(sub1 || 0) +
    Number(sub2 || 0) +
    Number(sub3 || 0) +
    Number(sub4 || 0);

  const percentage = total / 4;

  const status = percentage >= 40 ? "PASS" : "FAIL";

  return (
    <div>
      <h3>Result</h3>
      <p>Total: {total}</p>
      <p>Percentage: {percentage}</p>
      <p>Status: {status}</p>
    </div>
  );
}

export default Result;