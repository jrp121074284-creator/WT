import React, { useState } from "react";
import Student from "./Student";
import Result from "./Result";

function App() {

  const [marks, setMarks] = useState({
    sub1: "",
    sub2: "",
    sub3: "",
    sub4: ""
  });
  const [message, setMessage] = useState('')
  const studentData = {
    name: "Ashay",
    course: "Computer Engineering"
  };

  const handleChange = (e) => {
    setMarks({ ...marks, [e.target.name]: e.target.value });
  };

  const saveData = () => {
    fetch("http://localhost/backend/save.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ ...studentData, ...marks })
    });
    setMessage("Result Saved to DB");
  };

  return (
    <div>
      <h2>VIT Result System</h2>

      <Student data={studentData} />

      <br />

      <input name="sub1" placeholder="Subject 1" onChange={handleChange} />
      <input name="sub2" placeholder="Subject 2" onChange={handleChange} />
      <input name="sub3" placeholder="Subject 3" onChange={handleChange} />
      <input name="sub4" placeholder="Subject 4" onChange={handleChange} />

      <br /><br />

      <Result marks={marks} />

      <br />
      <button onClick={saveData}>Save to DB</button>
      <p>{message}</p>
    </div>
  );
}

export default App;