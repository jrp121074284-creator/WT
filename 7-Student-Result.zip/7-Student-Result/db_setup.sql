CREATE DATABASE vit_result;

USE vit_result;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    course VARCHAR(50),
    sub1 INT,
    sub2 INT,
    sub3 INT,
    sub4 INT
);