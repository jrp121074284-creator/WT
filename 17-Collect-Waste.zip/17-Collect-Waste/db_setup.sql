CREATE DATABASE waste_db;

USE waste_db;

CREATE TABLE waste_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(20),
    location VARCHAR(100),
    status VARCHAR(20) DEFAULT 'Pending'
);