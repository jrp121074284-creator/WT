<?php
$conn = mysqli_connect("localhost", "root", "", "waste_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $type = $_POST['type'];
    $location = $_POST['location'];

    $sql = "INSERT INTO waste_requests(type, location)
            VALUES('$type','$location')";
    mysqli_query($conn, $sql);

    echo "Request Submitted!";
}
?>

<h2>Waste Collection Request</h2>

<form method="POST">
    Waste Type:
    <select name="type">
        <option>Plastic</option>
        <option>Paper</option>
    </select>

    <br><br>

    Location:
    <input type="text" name="location" required>

    <br><br>

    <button name="submit">Submit</button>
</form>