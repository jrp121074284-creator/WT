<?php
$conn = mysqli_connect("localhost", "root", "", "waste_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Mark as Collected
if (isset($_GET['done'])) {
    $id = $_GET['done'];

    $sql = "UPDATE waste_requests SET status='Collected' WHERE id=$id";
    mysqli_query($conn, $sql);

    header("Location: admin.php");
    exit();
}

// Fetch data
$sql = "SELECT * FROM waste_requests";
$result = mysqli_query($conn, $sql);
?>

<h2>Waste Requests</h2>

<table border="1" cellpadding="10">
<tr>
    <th>ID</th>
    <th>Type</th>
    <th>Location</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['type']; ?></td>
    <td><?php echo $row['location']; ?></td>
    <td><?php echo $row['status']; ?></td>

    <td>
        <?php if ($row['status'] == "Pending") { ?>
            <a href="?done=<?php echo $row['id']; ?>">Mark Collected</a>
        <?php } ?>
    </td>
</tr>
<?php } ?>

</table>