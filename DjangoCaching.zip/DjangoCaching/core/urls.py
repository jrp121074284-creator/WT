from django.urls import path
from core import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('theme/<str:theme>/', views.set_theme_cookie, name='set_theme'),
]
