from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.decorators.cache import cache_page
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.utils import timezone
import datetime


def set_theme_cookie(request, theme):
    """Set theme preference in a cookie that expires in 30 days."""
    response = redirect('home')
    response.set_cookie('user_theme', theme, max_age=30*24*60*60)
    return response


def home(request):
    """Home page with theme from cookie."""
    theme = request.COOKIES.get('user_theme', 'light')
    return render(request, 'home.html', {'theme': theme})


def login_view(request):
    """Login view with session tracking."""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            # Track session info
            request.session['login_time'] = timezone.now().isoformat()
            request.session['username'] = user.username
            request.session['visit_count'] = 0
            messages.success(request, f'Welcome, {username}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid credentials. Try admin/admin or user/userpass')
    
    return render(request, 'login.html')


def logout_view(request):
    """Logout view that destroys the session."""
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('home')


@cache_page(60)
def dashboard(request):
    """Dashboard cached for 60 seconds with session tracking."""
    if not request.user.is_authenticated:
        return redirect('login')
    
    # Update session visit count
    request.session['visit_count'] = request.session.get('visit_count', 0) + 1
    request.session.modified = True
    
    theme = request.COOKIES.get('user_theme', 'light')
    
    session_data = {
        'username': request.session.get('username'),
        'login_time': request.session.get('login_time'),
        'visit_count': request.session.get('visit_count'),
        'session_id': request.session.session_key,
        'current_time': timezone.now().isoformat(),
    }
    
    context = {
        'theme': theme,
        'session_data': session_data,
        'user': request.user,
    }
    return render(request, 'dashboard.html', context)
