import { useDispatch } from "react-redux";
import { useState } from "react";

function NotificationForm() {

  const [msg, setMsg] = useState("");
  const dispatch = useDispatch();

  const addNotification = () => {
    if (!msg.trim()) return;

    dispatch({
      type: "ADD_NOTIFICATION",
      payload: msg
    });

    setMsg("");
  };

  return (
    <div className="form-box">

      <input
        type="text"
        placeholder="Enter notification..."
        value={msg}
        onChange={(e) => setMsg(e.target.value)}
      />

      <button onClick={addNotification}>
        Add
      </button>

    </div>
  );
}

export default NotificationForm;