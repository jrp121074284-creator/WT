import { useSelector, useDispatch } from "react-redux";
import { useState } from "react";

function NotificationList() {

  const { notifications } = useSelector(state => state);
  const dispatch = useDispatch();

  const [editId, setEditId] = useState(null);
  const [editText, setEditText] = useState("");

  const startEdit = (id, message) => {
    setEditId(id);
    setEditText(message);
  };

  const saveEdit = (id) => {
    if (!editText.trim()) return;

    dispatch({
      type: "UPDATE_NOTIFICATION",
      payload: { id: id, message: editText }
    });

    setEditId(null);
    setEditText("");
  };

  return (
    <div className="notif-container">

      {notifications.length === 0 && <p>No Notifications</p>}

      {notifications.map(n => (
        <div key={n.id} className="notif-card">

          {editId === n.id ? (
            <>
              <input
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
              />

              <button onClick={() => saveEdit(n.id)}>Save</button>
            </>
          ) : (
            <>
              <span>{n.message}</span>

              <div className="actions">
                <button onClick={() => startEdit(n.id, n.message)}>Update</button>

                <button
                  onClick={() =>
                    dispatch({
                      type: "REMOVE_NOTIFICATION",
                      payload: n.id
                    })
                  }
                >
                  Delete
                </button>
              </div>
            </>
          )}

        </div>
      ))}

    </div>
  );
}

export default NotificationList;