import NotificationForm from "./components/NotificationForm";
import NotificationList from "./components/NotificationList";
import "./App.css";

function App() {
  return (
    <div className="container">
      <h1>🔔 Notification System</h1>
      <NotificationForm />
      <NotificationList />
    </div>
  );
}

export default App;