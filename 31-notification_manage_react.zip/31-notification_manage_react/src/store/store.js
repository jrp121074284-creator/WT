import { createStore } from "redux";
import notificationReducer from "./notificationReducer";

const store = createStore(notificationReducer);

export default store;