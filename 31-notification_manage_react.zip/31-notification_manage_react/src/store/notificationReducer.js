const initialState = {
  notifications: []
};

function notificationReducer(state = initialState, action) {

  switch (action.type) {

    case "ADD_NOTIFICATION":
      return {
        ...state,
        notifications: [
          ...state.notifications,
          {
            id: Date.now(),
            message: action.payload
          }
        ]
      };

    case "REMOVE_NOTIFICATION":
      return {
        ...state,
        notifications: state.notifications.filter(
          n => n.id !== action.payload
        )
      };

    case "UPDATE_NOTIFICATION":
      return {
        ...state,
        notifications: state.notifications.map(n =>
          n.id === action.payload.id
            ? { ...n, message: action.payload.message }
            : n
        )
      };

    default:
      return state;
  }
}

export default notificationReducer;