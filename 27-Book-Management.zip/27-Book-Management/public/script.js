const API = "http://localhost:3000/books";

function loadBooks() {
    fetch(API)
        .then(res => res.json())
        .then(data => {
            let html = `
            <tr>
                <th>ID</th><th>Title</th><th>Author</th><th>Year</th><th>Action</th>
            </tr>`;

            data.forEach(b => {
                html += `
                <tr>
                    <td>${b.book_id}</td>
                    <td>${b.title}</td>
                    <td>${b.author}</td>
                    <td>${b.year}</td>
                    <td>
                        <button onclick="deleteBook(${b.book_id})">Delete</button>
                        <button onclick="fillForm(${b.book_id}, '${b.title}', '${b.author}', ${b.year})">Edit</button>
                    </td>
                </tr>`;
            });

            document.getElementById("table").innerHTML = html;
        });
}

function addBook() {
    const title = document.getElementById("title").value;
    const author = document.getElementById("author").value;
    const year = document.getElementById("year").value;

    fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, author, year })
    }).then(() => loadBooks());
}

// ✅ Fill form when clicking Edit
function fillForm(id, title, author, year) {
    document.getElementById("uid").value = id;
    document.getElementById("utitle").value = title;
    document.getElementById("uauthor").value = author;
    document.getElementById("uyear").value = year;
}

// ✅ Update Book
function updateBook() {
    const id = document.getElementById("uid").value;
    const title = document.getElementById("utitle").value;
    const author = document.getElementById("uauthor").value;
    const year = document.getElementById("uyear").value;

    fetch(API + "/" + id, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, author, year })
    }).then(() => loadBooks());
}

// DELETE
function deleteBook(id) {
    fetch(API + "/" + id, { method: "DELETE" })
        .then(() => loadBooks());
}

// Load on start
loadBooks();