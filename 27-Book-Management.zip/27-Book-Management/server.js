const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "ASP@2005",
    database: "book_db"
});

db.connect(err => {
    if (err) throw err;
    console.log("MySQL Connected");
});

// GET all books
app.get("/books", (req, res) => {
    db.query("SELECT * FROM books", (err, result) => {
        if (err) throw err;
        res.json(result);
    });
});

// ADD book
app.post("/books", (req, res) => {
    const { title, author, year } = req.body;

    db.query(
        "INSERT INTO books(title, author, year) VALUES(?,?,?)",
        [title, author, year],
        (err) => {
            if (err) throw err;
            res.send("Book Added");
        }
    );
});

// UPDATE book
app.put("/books/:id", (req, res) => {
    const { title, author, year } = req.body;

    db.query(
        "UPDATE books SET title=?, author=?, year=? WHERE book_id=?",
        [title, author, year, req.params.id],
        (err) => {
            if (err) throw err;
            res.send("Book Updated");
        }
    );
});

// DELETE book
app.delete("/books/:id", (req, res) => {
    db.query("DELETE FROM books WHERE book_id=?", [req.params.id], (err) => {
        if (err) throw err;
        res.send("Book Deleted");
    });
});

app.listen(3000, () => console.log("Server running on port 3000"));