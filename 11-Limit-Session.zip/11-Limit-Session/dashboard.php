<?php
session_start();

if (!isset($_SESSION['user'])) {
    echo "Login first";
    exit();
}

if (time() - $_SESSION['last_activity'] > 300) {
    session_destroy();
    echo "Session expired!";
    exit();
}

$_SESSION['last_activity'] = time();

echo "Welcome " . $_SESSION['user'];
?>

<br><br>
<a href="logout.php">Logout</a>