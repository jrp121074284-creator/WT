<?php
session_start();

$username = "user";
$password = "123";

if (isset($_POST['submit'])) {

    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if ($user == $username && $pass == $password) {

        $file = "sessions.txt";
        $sessions = [];

        if (file_exists($file)) {
            $sessions = json_decode(file_get_contents($file), true);
        }

        if (!isset($sessions[$user])) {
            $sessions[$user] = [];
        }

        // Remove expired sessions (5 min)
        $newSessions = [];
        foreach ($sessions[$user] as $s) {
            if (time() - $s['time'] < 300) {
                $newSessions[] = $s;
            }
        }
        $sessions[$user] = $newSessions;

        // Limit to 3 sessions
        if (count($sessions[$user]) >= 3) {
            echo "Max 3 sessions allowed!";
            exit();
        }

        // Add current session
        $sessions[$user][] = [
            "id" => session_id(),
            "time" => time()
        ];

        file_put_contents($file, json_encode($sessions));

        $_SESSION['user'] = $user;
        $_SESSION['last_activity'] = time();

        header("Location: dashboard.php");
        exit();

    } else {
        echo "Invalid login";
    }
}
?>

<form method="POST">
    Username: <input name="user"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <button name="submit">Login</button>
</form>