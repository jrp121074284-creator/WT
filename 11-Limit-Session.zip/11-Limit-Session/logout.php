<?php
session_start();

$user = $_SESSION['user'];
$file = "sessions.txt";

if (file_exists($file)) {
    $sessions = json_decode(file_get_contents($file), true);

    if (isset($sessions[$user])) {
        
        $sessions[$user] = array_filter($sessions[$user], function($s) {
            return $s['id'] != session_id();
        });

        file_put_contents($file, json_encode($sessions));
    }
}

session_destroy();

echo "Logged out";
?>