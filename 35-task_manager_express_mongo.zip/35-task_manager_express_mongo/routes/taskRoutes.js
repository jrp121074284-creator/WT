const express = require("express");
const router = express.Router();
const { create, read, update, remove } = require("../controllers/taskController");

router.post("/tasks", create);
router.get("/tasks", read);
router.put("/tasks/:id", update);     // update status
router.delete("/tasks/:id", remove);

module.exports = router;