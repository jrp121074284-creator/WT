const { getDB } = require("../config");

// ADD TASK
async function addTask(data) {
  const db = getDB();

  return db.collection("tasks").insertOne({
    task_id: data.task_id,
    title: data.title,
    status: "pending"   // default
  });
}

// GET ALL TASKS
async function getTasks() {
  const db = getDB();
  return db.collection("tasks").find().toArray();
}

// UPDATE STATUS
async function updateStatus(task_id, status) {
  const db = getDB();

  return db.collection("tasks").updateOne(
    { task_id: task_id },
    { $set: { status: status } }
  );
}

// DELETE TASK
async function deleteTask(task_id) {
  const db = getDB();
  return db.collection("tasks").deleteOne({ task_id: task_id });
}

module.exports = { addTask, getTasks, updateStatus, deleteTask };