const { addTask, getTasks, updateStatus, deleteTask } = require("../models/taskModel");

// ADD
async function create(req, res) {
  if (!req.body.task_id || !req.body.title) {
    return res.json({ message: "All fields required" });
  }

  await addTask(req.body);
  res.json({ message: "Task Added" });
}

// GET
async function read(req, res) {
  const data = await getTasks();
  res.json(data);
}

// UPDATE STATUS
async function update(req, res) {
  const result = await updateStatus(req.params.id, req.body.status);

  if (result.matchedCount === 0) {
    return res.json({ message: "Task not found" });
  }

  res.json({ message: "Status Updated" });
}

// DELETE
async function remove(req, res) {
  const result = await deleteTask(req.params.id);

  if (result.deletedCount === 0) {
    return res.json({ message: "Task not found" });
  }

  res.json({ message: "Task Deleted" });
}

module.exports = { create, read, update, remove };