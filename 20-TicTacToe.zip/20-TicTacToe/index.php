<?php
session_start();

// Initialize board
if (!isset($_SESSION['board'])) {
    $_SESSION['board'] = array_fill(0, 9, "");
    $_SESSION['player'] = "X";
}

// Handle move
if (isset($_GET['cell'])) {
    $i = $_GET['cell'];

    if ($_SESSION['board'][$i] == "") {
        $_SESSION['board'][$i] = $_SESSION['player'];

        // Switch player
        $_SESSION['player'] = ($_SESSION['player'] == "X") ? "O" : "X";
    }
}

// Check winner
function checkWinner($b) {
    $wins = [
        [0,1,2],[3,4,5],[6,7,8], // rows
        [0,3,6],[1,4,7],[2,5,8], // cols
        [0,4,8],[2,4,6]          // diagonals
    ];

    foreach ($wins as $w) {
        if ($b[$w[0]] != "" &&
            $b[$w[0]] == $b[$w[1]] &&
            $b[$w[1]] == $b[$w[2]]) {
            return $b[$w[0]];
        }
    }
    return "";
}

$winner = checkWinner($_SESSION['board']);

// Reset game
if (isset($_GET['reset'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<h2>Tic Tac Toe</h2>

<table border="1" cellpadding="20">
<?php
for ($i = 0; $i < 9; $i++) {

    if ($i % 3 == 0) echo "<tr>";

    echo "<td align='center' width='50' height='50'>";

    if ($_SESSION['board'][$i] == "" && $winner == "") {
        echo "<a href='?cell=$i'>-</a>";
    } else {
        echo $_SESSION['board'][$i];
    }

    echo "</td>";

    if ($i % 3 == 2) echo "</tr>";
}
?>
</table>

<br>

<?php
if ($winner != "") {
    echo "<h3>Winner: $winner</h3>";
} else {
    echo "<h3>Current Player: " . $_SESSION['player'] . "</h3>";
}
?>

<br>
<a href="?reset=1">Reset Game</a>