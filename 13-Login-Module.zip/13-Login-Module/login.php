<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "login_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['login'])) {

    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM users WHERE username='$user' AND password='$pass'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {

        $_SESSION['user'] = $user;

        // Cookie (1 hour)
        setcookie("username", $user, time()+3600);

        header("Location: dashboard.php");
        exit();

    } else {
        echo "Invalid Login";
    }
}
?>

<h2>Login</h2>

<form method="POST">
    Username: <input name="user"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <button name="login">Login</button>
</form>