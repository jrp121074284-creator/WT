<?php
$conn = mysqli_connect("localhost", "root", "", "login_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['register'])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $sql = "INSERT INTO users(username,password) VALUES('$user','$pass')";
    mysqli_query($conn, $sql);

    echo "Registered Successfully";
}
?>

<h2>Register</h2>

<form method="POST">
    Username: <input name="user"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <button name="register">Register</button>
</form>