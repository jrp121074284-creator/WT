import React, { useState } from "react";

function App() {

  const [dollars, setDollars] = useState("");
  const [rupees, setRupees] = useState(0);

  const convert = () => {
    const rate = 83; // simple fixed rate (1 USD = 83 INR)
    setRupees(dollars * rate);
  };

  return (
    <div>

      <h2>Currency Converter</h2>

      <input
        type="number"
        placeholder="Enter Dollars"
        value={dollars}
        onChange={(e) => setDollars(e.target.value)}
      />

      <br /><br />

      <button onClick={convert}>Convert</button>

      <h3>Rupees: {rupees}</h3>

    </div>
  );
}

export default App;