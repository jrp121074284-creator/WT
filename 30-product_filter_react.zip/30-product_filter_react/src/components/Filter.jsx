import { useDispatch, useSelector } from "react-redux";

function Filter() {

  const dispatch = useDispatch();
  const { category, maxPrice } = useSelector(state => state);

  return (
    <div className="filter-box">

      {/* CATEGORY */}
      <select
        value={category}
        onChange={(e) =>
          dispatch({ type: "SET_CATEGORY", payload: e.target.value })
        }
      >
        <option value="All">All</option>
        <option value="Electronics">Electronics</option>
        <option value="Clothing">Clothing</option>
        <option value="Accessories">Accessories</option>
      </select>

      {/* PRICE INPUT */}
      <input
  type="number"
  placeholder="Enter Max Price"
  value={maxPrice === 100000 ? "" : maxPrice}
  onChange={(e) =>
    dispatch({
      type: "SET_PRICE",
      payload: e.target.value === "" ? 100000 : Number(e.target.value)
    })
  }
/>

      {/* BUTTONS */}
      <button onClick={() => dispatch({ type: "FILTER" })}>
        Apply
      </button>

      <button className="reset" onClick={() => dispatch({ type: "RESET" })}>
        Reset
      </button>

    </div>
  );
}

export default Filter;