import { useSelector } from "react-redux";

function ProductList() {

  const { products, filteredProducts } = useSelector(state => state);

  const data = filteredProducts.length > 0 ? filteredProducts : products;

  return (
    <div className="grid">

      {data.map(p => (
        <div key={p.id} className="card">
          <h3>{p.name}</h3>
          <p>{p.category}</p>
          <p>₹{p.price}</p>
        </div>
      ))}

    </div>
  );
}

export default ProductList;