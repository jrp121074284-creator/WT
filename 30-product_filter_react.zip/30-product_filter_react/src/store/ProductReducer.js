const initialState = {
  products: [
    { id: 1, name: "Laptop", category: "Electronics", price: 60000 },
    { id: 2, name: "Phone", category: "Electronics", price: 30000 },
    { id: 3, name: "Shirt", category: "Clothing", price: 1500 },
    { id: 4, name: "Shoes", category: "Clothing", price: 3000 },
    { id: 5, name: "Watch", category: "Accessories", price: 5000 }
  ],
  filteredProducts: [],
  category: "All",
  maxPrice: 100000
};

function productReducer(state = initialState, action) {

  switch (action.type) {

    case "SET_CATEGORY":
      return { ...state, category: action.payload };

    case "SET_PRICE":
      return { ...state, maxPrice: action.payload };

    case "FILTER":
      const filtered = state.products.filter(p =>
        (state.category === "All" || p.category === state.category) &&
        p.price <= state.maxPrice
      );
      return { ...state, filteredProducts: filtered };

    case "RESET":
      return {
        ...state,
        category: "All",
        maxPrice: 100000,
        filteredProducts: []
      };

    default:
      return state;
  }
}

export default productReducer;