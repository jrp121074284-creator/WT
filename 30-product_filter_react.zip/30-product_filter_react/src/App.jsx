import Filter from "./components/Filter";
import ProductList from "./components/ProductList";
import "./App.css";

function App() {
  return (
    <div className="container">
      <h1>🛍 Product Filter</h1>
      <Filter />
      <ProductList />
    </div>
  );
}

export default App;