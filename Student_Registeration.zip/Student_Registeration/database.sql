create database student_registeration;

use student_registeration;

create table students (
    id int auto_increment not null primary key,
    name varchar(255) not null,
    email varchar(255) not null, 
    course varchar(255) not null
);

