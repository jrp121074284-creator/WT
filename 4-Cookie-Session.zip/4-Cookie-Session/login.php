<?php
session_start();
?>

<!DOCTYPE html>
<html>
<body>

<h2>Login</h2>

<form method="POST">
    Username: <input type="text" name="user"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <input type="submit" name="submit" value="Login">
</form>

<?php

if (isset($_POST['submit'])) {

    if ($_POST['user'] == "admin" && $_POST['pass'] == "123") {
        $_SESSION['user'] = "admin";
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Wrong Credentials";
    }
}

?>

</body>
</html>