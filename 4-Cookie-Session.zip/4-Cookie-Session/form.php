<?php
?>

<!DOCTYPE html>
<html>
<body>

<h2>Simple Form</h2>

<form method="POST">
    Name: <input type="text" name="name"><br><br>
    Email: <input type="text" name="email"><br><br>
    <input type="submit" name="submit" value="Submit">
</form>

<?php

if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid Email";
    } else {
        echo "Valid Email<br>";

        setcookie("username", $name, time()+3600);

        echo "Cookie set for $name";
    }
}

?>

</body>
</html>