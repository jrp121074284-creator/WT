<?php
session_start();

if (!isset($_SESSION['user'])) {
    echo "Please login first";
    exit();
}
?>

<!DOCTYPE html>
<html>
<body>

<h2>Welcome <?php echo $_SESSION['user']; ?></h2>

<?php
if (isset($_COOKIE['username'])) {
    echo "Cookie User: " . $_COOKIE['username'];
}
?>

<br><br>
<a href="login.php">Go Back</a>

</body>
</html>