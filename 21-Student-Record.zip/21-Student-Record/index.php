<?php

$conn = mysqli_connect("localhost", "root", "", "student_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// ADD
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "INSERT INTO students(name, email) VALUES('$name', '$email')";
    mysqli_query($conn, $sql);

    header("Location: index.php");
    exit();
}

// DELETE
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM students WHERE id = $id";
    mysqli_query($conn, $sql);

    header("Location: index.php");
    exit();
}

// UPDATE
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "UPDATE students SET name='$name', email='$email' WHERE id=$id";
    mysqli_query($conn, $sql);

    header("Location: index.php");
    exit();
}

// SELECT
$sql = "SELECT * FROM students";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html>
<body>

<h2>Student CRUD</h2>

<form method="POST">
    Name: <input type="text" name="name" required>
    Email: <input type="text" name="email" required>
    <button name="add">Add</button>
</form>

<br><br>

<table border="1" cellpadding="10">
<tr>
    <th>ID</th><th>Name</th><th>Email</th><th>Action</th>
</tr>

<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <form method="POST">
        <td><?php echo htmlspecialchars($row['id']); ?></td>
        <td><input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>"></td>
        <td><input type="text" name="email" value="<?php echo htmlspecialchars($row['email']); ?>"></td>
        <td>
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <button name="update">Update</button>
        </td>
    </form>
    <td><a href="?delete=<?php echo $row['id']; ?>">Delete</a></td>
</tr>
<?php } ?>

</table>

</body>
</html>