CREATE DATABASE complaint_sys;

USE complaint_sys;

CREATE TABLE complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    organization VARCHAR(50),
    complaint TEXT
);