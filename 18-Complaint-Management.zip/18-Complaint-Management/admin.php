<?php
$conn = mysqli_connect("localhost", "root", "", "complaint_sys");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM complaints";
$result = mysqli_query($conn, $sql);
?>

<h2>All Complaints</h2>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Organization</th>
    <th>Complaint</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['organization']; ?></td>
    <td><?php echo $row['complaint']; ?></td>
</tr>
<?php } ?>

</table>