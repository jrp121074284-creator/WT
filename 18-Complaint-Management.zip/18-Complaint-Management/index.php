<?php
$conn = mysqli_connect("localhost", "root", "", "complaint_sys");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $org = $_POST['org'];
    $complaint = $_POST['complaint'];

    $sql = "INSERT INTO complaints(name, organization, complaint)
            VALUES('$name','$org','$complaint')";
    mysqli_query($conn, $sql);

    echo "Complaint Submitted!";
}
?>

<h2>Complaint Form</h2>

<form method="POST">

    Name: <input type="text" name="name" required><br><br>

    Organization:
    <select name="org">
        <option>PMC</option>
        <option>PMT</option>
        <option>College</option>
    </select>

    <br><br>

    Complaint:
    <textarea name="complaint" required></textarea>

    <br><br>

    <button name="submit">Submit</button>

</form>