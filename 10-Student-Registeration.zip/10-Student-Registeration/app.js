const express = require("express");
const app = express();
const db = require("./db.js");

const cors = require("cors");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post("/add-student", (req, res) => {
  const { name: student_name, email, course } = req.body;
  const sql = "INSERT INTO students (name, email, course) VALUES (?, ?, ?)";

  db.query(sql, [student_name, email, course], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ message: "Error saving student" });
    }

    res.json({
      message: "Student added successfully",
      studentId: result.insertId,
    });
  });
});

app.get("/get-all-students", (req, res) => {
  const sql = "SELECT * FROM students";

  db.query(sql, (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ message: "Error getting students" });
    }

    console.log(result);

    const students = result.map((student) => ({
      name: student.name,
      email: student.email,
      course: student.course,
    }));
    res.json({ students });
  });
});

app.get("/get-student/:id", (req, res) => {
  const sql = "SELECT * FROM students WHERE id=?";
  const { id } = req.params;
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ message: "Error getting student" });
    }

    const students = result.map((student) => ({
      name: student.name,
      email: student.email,
      course: student.course,
    }));

    console.log("get student ",students);
    res.json({ students });
  });
});

app.put("/update-student/:id", (req, res) => {
  const { name: student_name, email, course } = req.body;
  const sql =
    "UPDATE students SET name = ?, email = ?, course = ? WHERE id = ?";
  const { id } = req.params;
  db.query(sql, [student_name, email, course, id], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ message: "Error updating student" });
    }

    res.json({
      message: "Student updated successfully",
      affectedRows: result.affectedRows,
    });
  });
});

app.delete("/delete-student/:id", (req, res) => {
  const { id } = req.params;
  const sql = "DELETE FROM students WHERE id = ?";

  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ message: "Error deleting student" });
    }

    res.json({
      message: "Student updated successfully",
      affectedRows: result.affectedRows,
    });
  });
});

app.listen(3000, () => {
  console.log("http://localhost:3000");
});
