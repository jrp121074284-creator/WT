<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electricity Bill Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e8f4f8;
            margin: 20px;
        }

        h1 {
            color: #333333;
            text-align: center;
            text-decoration: underline;
        }

        h2 {
            color: #0000cc;
        }

        p {
            font-size: 14px;
        }

        .main-div {
            background-color: white;
            width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 2px solid #aaaaaa;
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        input[type="text"], input[type="number"] {
            width: 250px;
            padding: 5px;
            margin-top: 4px;
            margin-bottom: 12px;
            border: 1px solid #999999;
        }

        input[type="submit"] {
            background-color: #0066cc;
            color: white;
            padding: 6px 18px;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }

        input[type="reset"] {
            background-color: #888888;
            color: white;
            padding: 6px 14px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-left: 8px;
        }

        .error-msg {
            color: red;
            font-size: 13px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 10px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th {
            background-color: #ccddff;
            padding: 7px;
            text-align: left;
            font-size: 14px;
        }

        td {
            padding: 6px 8px;
            font-size: 14px;
        }

        .total-row {
            background-color: #ffffcc;
            font-weight: bold;
        }

        .result-box {
            background-color: #f0fff0;
            border: 1px solid green;
            padding: 10px;
            margin-top: 15px;
        }

        hr {
            border: 1px solid #cccccc;
            margin: 20px 0;
        }
    </style>
</head>
<body>

<div class="main-div">

    <h1>Electricity Bill Calculator</h1>

    <hr>

    <?php
    $units      = 0;
    $name       = '';
    $bill       = 0;
    $calculated = false;
    $error      = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name  = trim($_POST['name']  ?? '');
        $units = trim($_POST['units'] ?? '');

        if (empty($name)) {
            $error = "Please enter the customer name.";
        } elseif (!is_numeric($units) || $units < 0) {
            $error = "Please enter a valid number of units (0 or above).";
        } else {
            $units = floatval($units);

            if ($units <= 50) {
                $bill = $units * 3.50;
            } elseif ($units <= 150) {
                $bill = (50 * 3.50) + (($units - 50) * 4.00);
            } elseif ($units <= 250) {
                $bill = (50 * 3.50) + (100 * 4.00) + (($units - 150) * 5.20);
            } else {
                $bill = (50 * 3.50) + (100 * 4.00) + (100 * 5.20) + (($units - 250) * 6.50);
            }

            $calculated = true;
        }
    }
    ?>

    <h2>Enter Details</h2>

    <?php if (!empty($error)): ?>
        <p class="error-msg">* <?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <table style="border:none; width:auto;">
            <tr>
                <td style="border:none; padding: 4px 8px;"><label>Customer Name :</label></td>
                <td style="border:none; padding: 4px 8px;">
                    <input type="text" name="name"
                           placeholder="Enter name"
                           value="<?= htmlspecialchars($name) ?>">
                </td>
            </tr>
            <tr>
                <td style="border:none; padding: 4px 8px;"><label>Units Consumed :</label></td>
                <td style="border:none; padding: 4px 8px;">
                    <input type="number" name="units"
                           placeholder="Enter units"
                           min="0" step="0.01"
                           value="<?= $units > 0 ? htmlspecialchars($units) : '' ?>">
                </td>
            </tr>
            <tr>
                <td style="border:none;"></td>
                <td style="border:none; padding-top: 8px;">
                    <input type="submit" value="Calculate Bill">
                    <input type="reset" value="Clear">
                </td>
            </tr>
        </table>
    </form>

    <?php if ($calculated): ?>

        <hr>

        <div class="result-box">
            <h2>Bill Details - <?= htmlspecialchars($name) ?></h2>

            <table>
                <tr>
                    <th>Description</th>
                    <th>Units</th>
                    <th>Rate (Rs/unit)</th>
                    <th>Amount (Rs)</th>
                </tr>

                <?php if ($units >= 1): ?>
                <tr>
                    <td>First 50 units</td>
                    <td><?= min($units, 50) ?></td>
                    <td>3.50</td>
                    <td><?= number_format(min($units, 50) * 3.50, 2) ?></td>
                </tr>
                <?php endif; ?>

                <?php if ($units > 50): ?>
                <tr>
                    <td>Next 100 units (51 to 150)</td>
                    <td><?= min($units - 50, 100) ?></td>
                    <td>4.00</td>
                    <td><?= number_format(min($units - 50, 100) * 4.00, 2) ?></td>
                </tr>
                <?php endif; ?>

                <?php if ($units > 150): ?>
                <tr>
                    <td>Next 100 units (151 to 250)</td>
                    <td><?= min($units - 150, 100) ?></td>
                    <td>5.20</td>
                    <td><?= number_format(min($units - 150, 100) * 5.20, 2) ?></td>
                </tr>
                <?php endif; ?>

                <?php if ($units > 250): ?>
                <tr>
                    <td>Above 250 units</td>
                    <td><?= $units - 250 ?></td>
                    <td>6.50</td>
                    <td><?= number_format(($units - 250) * 6.50, 2) ?></td>
                </tr>
                <?php endif; ?>

                <tr class="total-row">
                    <td colspan="3">Total Bill Amount</td>
                    <td>Rs. <?= number_format($bill, 2) ?></td>
                </tr>
            </table>
        </div>

    <?php endif; ?>

    <hr>

    <h2>Rate Chart</h2>
    <table>
        <tr>
            <th>Units</th>
            <th>Rate (Rs. per unit)</th>
        </tr>
        <tr>
            <td>1 to 50 units</td>
            <td>Rs. 3.50</td>
        </tr>
        <tr>
            <td>51 to 150 units</td>
            <td>Rs. 4.00</td>
        </tr>
        <tr>
            <td>151 to 250 units</td>
            <td>Rs. 5.20</td>
        </tr>
        <tr>
            <td>251 and above</td>
            <td>Rs. 6.50</td>
        </tr>
    </table>

    <br>
    <p style="text-align:center; color:gray; font-size:12px;">-- End of Page --</p>

</div>

</body>
</html>