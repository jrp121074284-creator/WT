# 🔐 Spring Boot Login Security — Failed Attempt Tracker

A Spring Boot application that tracks failed login attempts, locks accounts after too many failures, and auto-unlocks after a configurable duration.

---

## ✅ Features

| Feature | Details |
|---------|---------|
| Spring Security | Form-based login with custom handlers |
| Track failed logins | Every attempt logged to DB with IP, timestamp, reason |
| Account locking | Locked after **5 failed attempts** (configurable) |
| Auto-unlock | Automatically unlocks after **15 minutes** (configurable) |
| Error messages | Shows remaining attempts, lock timer, reason |
| Admin panel | View/lock/unlock all accounts |
| H2 Console | In-memory DB browser for debugging |

---

## 🚀 How to Run

### Prerequisites
- **Java 17+** — [Download](https://adoptium.net/)
- **Maven 3.6+** — [Download](https://maven.apache.org/)

Verify versions:
```bash
java -version
mvn -version
```

### Step 1 — Extract the ZIP
```bash
unzip login-security.zip
cd login-security
```

### Step 2 — Build & Run
```bash
mvn spring-boot:run
```

Or build a JAR first:
```bash
mvn clean package -DskipTests
java -jar target/login-tracker-1.0.0.jar
```

### Step 3 — Open the App
```
http://localhost:8080/login
```

---

## 🔑 Demo Credentials

| Username     | Password   | Role  | Status        |
|--------------|------------|-------|---------------|
| `user`       | `user123`  | USER  | Active        |
| `admin`      | `admin123` | ADMIN | Active        |
| `lockeduser` | —          | USER  | Pre-locked    |

---

## 🧪 Testing the Features

### Test account locking:
1. Go to `http://localhost:8080/login`
2. Enter username `user` with a **wrong password** 5 times
3. On the 5th failure → account locks
4. The login page shows: **"Account Locked — try again in X minutes"**
5. Wait 15 minutes OR use the admin panel to unlock

### Test admin unlock:
1. Log in as `admin / admin123`
2. Go to `http://localhost:8080/admin/users`
3. Find the locked user → click **🔓 Unlock**

### Test remaining-attempts warning:
1. Enter wrong password once — see "4 attempts remaining"
2. Enter wrong password again — see "3 attempts remaining"
3. ... until locked

---

## ⚙️ Configuration

Edit `src/main/resources/application.properties`:

```properties
# Number of failures before account locks (default: 5)
app.security.max-failed-attempts=5

# How long (minutes) the account stays locked (default: 15)
app.security.lock-duration-minutes=15

# Server port (default: 8080)
server.port=8080
```

---

## 🗄️ H2 Database Console

Access the in-memory database browser at:

```
http://localhost:8080/h2-console
```

| Field    | Value              |
|----------|--------------------|
| JDBC URL | `jdbc:h2:mem:logindb` |
| Username | `sa`               |
| Password | *(leave blank)*    |

Tables: `USERS`, `LOGIN_ATTEMPTS`

---

## 📁 Project Structure

```
login-security/
├── pom.xml
└── src/main/
    ├── java/com/security/logintracker/
    │   ├── LoginTrackerApplication.java       ← Entry point
    │   ├── config/
    │   │   ├── SecurityConfig.java            ← Spring Security config
    │   │   ├── CustomAuthenticationSuccessHandler.java
    │   │   ├── CustomAuthenticationFailureHandler.java
    │   │   └── DataInitializer.java           ← Seeds demo users
    │   ├── controller/
    │   │   ├── LoginController.java
    │   │   ├── DashboardController.java
    │   │   └── AdminController.java
    │   ├── model/
    │   │   ├── User.java
    │   │   └── LoginAttempt.java
    │   ├── repository/
    │   │   ├── UserRepository.java
    │   │   └── LoginAttemptRepository.java
    │   └── service/
    │       ├── CustomUserDetailsService.java
    │       └── LoginAttemptService.java
    └── resources/
        ├── application.properties
        ├── static/css/style.css
        └── templates/
            ├── login.html
            ├── dashboard.html
            └── admin/users.html
```

---

## 🐞 Troubleshooting

| Problem | Solution |
|---------|----------|
| `java: error: release version 17 not supported` | Upgrade to Java 17+ |
| Port 8080 already in use | Change `server.port=9090` in `application.properties` |
| Account auto-unlock not working | Check server time; lock timer uses `LocalDateTime.now()` |
| Can't access H2 console | Ensure `spring.h2.console.enabled=true` in properties |
