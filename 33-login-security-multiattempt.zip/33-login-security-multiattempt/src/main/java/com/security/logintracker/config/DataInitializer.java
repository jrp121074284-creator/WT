package com.security.logintracker.config;

import com.security.logintracker.model.User;
import com.security.logintracker.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Create demo regular user
        if (userRepository.findByUsername("user").isEmpty()) {
            userRepository.save(User.builder()
                    .username("user")
                    .password(passwordEncoder.encode("user123"))
                    .email("user@example.com")
                    .role("USER")
                    .enabled(true)
                    .accountNonLocked(true)
                    .failedAttempts(0)
                    .build());
            log.info("Created demo user: username=user / password=user123");
        }

        // Create admin user
        if (userRepository.findByUsername("admin").isEmpty()) {
            userRepository.save(User.builder()
                    .username("admin")
                    .password(passwordEncoder.encode("admin123"))
                    .email("admin@example.com")
                    .role("ADMIN")
                    .enabled(true)
                    .accountNonLocked(true)
                    .failedAttempts(0)
                    .build());
            log.info("Created demo admin: username=admin / password=admin123");
        }

        // Create a pre-locked user for testing
        if (userRepository.findByUsername("lockeduser").isEmpty()) {
            userRepository.save(User.builder()
                    .username("lockeduser")
                    .password(passwordEncoder.encode("locked123"))
                    .email("locked@example.com")
                    .role("USER")
                    .enabled(true)
                    .accountNonLocked(false)
                    .failedAttempts(5)
                    .lockTime(java.time.LocalDateTime.now())
                    .build());
            log.info("Created locked demo user: username=lockeduser (already locked)");
        }

        log.info("============================================");
        log.info("  Application started at http://localhost:8080");
        log.info("  Demo credentials:");
        log.info("    user / user123   (regular user)");
        log.info("    admin / admin123  (admin user)");
        log.info("    lockeduser       (locked account)");
        log.info("  H2 Console: http://localhost:8080/h2-console");
        log.info("  JDBC URL:   jdbc:h2:mem:logindb");
        log.info("============================================");
    }
}
