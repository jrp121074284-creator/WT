package com.security.logintracker.controller;

import com.security.logintracker.model.LoginAttempt;
import com.security.logintracker.service.LoginAttemptService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final LoginAttemptService loginAttemptService;

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        String username = authentication.getName();
        List<LoginAttempt> recentAttempts = loginAttemptService.getRecentAttempts(username);

        model.addAttribute("username", username);
        model.addAttribute("recentAttempts", recentAttempts);
        model.addAttribute("authorities", authentication.getAuthorities());
        return "dashboard";
    }
}
