package com.security.logintracker.repository;

import com.security.logintracker.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    @Modifying
    @Query("UPDATE User u SET u.failedAttempts = ?1 WHERE u.username = ?2")
    void updateFailedAttempts(int attempts, String username);

    @Modifying
    @Query("UPDATE User u SET u.accountNonLocked = true, u.failedAttempts = 0, u.lockTime = null WHERE u.username = ?1")
    void unlockAccount(String username);
}
