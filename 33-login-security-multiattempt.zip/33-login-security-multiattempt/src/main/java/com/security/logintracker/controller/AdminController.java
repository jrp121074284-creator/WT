package com.security.logintracker.controller;

import com.security.logintracker.model.User;
import com.security.logintracker.repository.UserRepository;
import com.security.logintracker.service.LoginAttemptService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final LoginAttemptService loginAttemptService;

    @GetMapping("/users")
    public String manageUsers(Model model) {
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        model.addAttribute("maxAttempts", loginAttemptService.getMaxFailedAttempts());
        model.addAttribute("lockMinutes", loginAttemptService.getLockDurationMinutes());
        return "admin/users";
    }

    @PostMapping("/users/{id}/unlock")
    public String unlockUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        userRepository.findById(id).ifPresentOrElse(user -> {
            loginAttemptService.unlockUser(user);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Account for '" + user.getUsername() + "' has been unlocked.");
        }, () -> redirectAttributes.addFlashAttribute("errorMessage", "User not found."));

        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/lock")
    public String lockUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        userRepository.findById(id).ifPresentOrElse(user -> {
            loginAttemptService.lockUser(user);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Account for '" + user.getUsername() + "' has been manually locked.");
        }, () -> redirectAttributes.addFlashAttribute("errorMessage", "User not found."));

        return "redirect:/admin/users";
    }
}
