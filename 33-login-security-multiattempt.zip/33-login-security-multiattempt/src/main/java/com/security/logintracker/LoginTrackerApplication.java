package com.security.logintracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginTrackerApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoginTrackerApplication.class, args);
    }
}
