package com.security.logintracker.service;

import com.security.logintracker.model.LoginAttempt;
import com.security.logintracker.model.User;
import com.security.logintracker.repository.LoginAttemptRepository;
import com.security.logintracker.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class LoginAttemptService {

    private final UserRepository userRepository;
    private final LoginAttemptRepository loginAttemptRepository;

    @Value("${app.security.max-failed-attempts:5}")
    private int maxFailedAttempts;

    @Value("${app.security.lock-duration-minutes:15}")
    private int lockDurationMinutes;

    /**
     * Called on successful login — resets failed attempts and logs success.
     */
    @Transactional
    public void loginSucceeded(String username, String ipAddress) {
        userRepository.findByUsername(username).ifPresent(user -> {
            userRepository.updateFailedAttempts(0, username);
            log.info("Successful login for user: {}", username);
        });

        loginAttemptRepository.save(LoginAttempt.builder()
                .username(username)
                .ipAddress(ipAddress)
                .success(true)
                .attemptTime(LocalDateTime.now())
                .build());
    }

    /**
     * Called on failed login — increments counter and locks if threshold reached.
     */
    @Transactional
    public void loginFailed(String username, String ipAddress, String reason) {
        loginAttemptRepository.save(LoginAttempt.builder()
                .username(username)
                .ipAddress(ipAddress)
                .success(false)
                .failureReason(reason)
                .attemptTime(LocalDateTime.now())
                .build());

        userRepository.findByUsername(username).ifPresent(user -> {
            int newAttempts = user.getFailedAttempts() + 1;

            if (newAttempts >= maxFailedAttempts) {
                lockUser(user);
                log.warn("Account LOCKED for user: {} after {} failed attempts", username, newAttempts);
            } else {
                userRepository.updateFailedAttempts(newAttempts, username);
                log.warn("Failed login attempt #{} for user: {}", newAttempts, username);
            }
        });
    }

    /**
     * Locks a user account and records the lock time.
     */
    @Transactional
    public void lockUser(User user) {
        user.setAccountNonLocked(false);
        user.setLockTime(LocalDateTime.now());
        user.setFailedAttempts(maxFailedAttempts);
        userRepository.save(user);
    }

    /**
     * Unlocks a user account and resets counters.
     */
    @Transactional
    public void unlockUser(User user) {
        userRepository.unlockAccount(user.getUsername());
        log.info("Account UNLOCKED for user: {}", user.getUsername());
    }

    /**
     * Returns true if the lock duration has elapsed since the account was locked.
     */
    public boolean isUnlockTimeReached(User user) {
        if (user.getLockTime() == null) return true;
        LocalDateTime unlockTime = user.getLockTime().plusMinutes(lockDurationMinutes);
        return LocalDateTime.now().isAfter(unlockTime);
    }

    /**
     * Returns minutes remaining until the account is unlocked.
     */
    public long getMinutesUntilUnlock(User user) {
        if (user.getLockTime() == null) return 0;
        LocalDateTime unlockTime = user.getLockTime().plusMinutes(lockDurationMinutes);
        long minutes = java.time.Duration.between(LocalDateTime.now(), unlockTime).toMinutes();
        return Math.max(0, minutes + 1); // round up
    }

    /**
     * Returns recent login attempt history for a user.
     */
    public List<LoginAttempt> getRecentAttempts(String username) {
        return loginAttemptRepository.findByUsernameOrderByAttemptTimeDesc(username);
    }

    public int getMaxFailedAttempts() {
        return maxFailedAttempts;
    }

    public int getLockDurationMinutes() {
        return lockDurationMinutes;
    }
}
