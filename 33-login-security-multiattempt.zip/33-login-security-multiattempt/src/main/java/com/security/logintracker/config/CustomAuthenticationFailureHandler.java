package com.security.logintracker.config;

import com.security.logintracker.model.User;
import com.security.logintracker.repository.UserRepository;
import com.security.logintracker.service.LoginAttemptService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.*;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    private final LoginAttemptService loginAttemptService;
    private final UserRepository userRepository;

    @Override
    public void onAuthenticationFailure(HttpServletRequest request,
                                        HttpServletResponse response,
                                        AuthenticationException exception) throws IOException {

        String username = request.getParameter("username");
        String ipAddress = getClientIP(request);
        String errorParam;

        if (exception instanceof LockedException) {
            // Account is already locked
            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isPresent()) {
                long minutes = loginAttemptService.getMinutesUntilUnlock(userOpt.get());
                errorParam = "locked&minutes=" + minutes;
            } else {
                errorParam = "locked&minutes=" + loginAttemptService.getLockDurationMinutes();
            }
            log.warn("Blocked login attempt for LOCKED account: {}", username);

        } else if (exception instanceof DisabledException) {
            errorParam = "disabled";
            log.warn("Login attempt for DISABLED account: {}", username);

        } else if (exception instanceof BadCredentialsException) {
            // Track the failed attempt
            loginAttemptService.loginFailed(username, ipAddress, "Bad credentials");

            // Check if account just got locked after this attempt
            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isPresent() && userOpt.get().isLocked()) {
                long minutes = loginAttemptService.getMinutesUntilUnlock(userOpt.get());
                errorParam = "locked&minutes=" + minutes;
            } else {
                int attemptsLeft = userOpt.map(u ->
                        loginAttemptService.getMaxFailedAttempts() - u.getFailedAttempts()
                ).orElse(0);
                errorParam = "invalid&remaining=" + attemptsLeft;
            }

        } else {
            loginAttemptService.loginFailed(username, ipAddress, exception.getMessage());
            errorParam = "error";
        }

        response.sendRedirect("/login?error=" + errorParam);
    }

    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
