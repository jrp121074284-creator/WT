package com.security.logintracker.repository;

import com.security.logintracker.model.LoginAttempt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface LoginAttemptRepository extends JpaRepository<LoginAttempt, Long> {

    List<LoginAttempt> findByUsernameOrderByAttemptTimeDesc(String username);

    List<LoginAttempt> findByUsernameAndAttemptTimeAfterOrderByAttemptTimeDesc(
            String username, LocalDateTime since);

    long countByUsernameAndSuccessAndAttemptTimeAfter(
            String username, boolean success, LocalDateTime since);
}
