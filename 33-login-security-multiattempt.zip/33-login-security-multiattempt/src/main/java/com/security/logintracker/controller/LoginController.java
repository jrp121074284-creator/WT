package com.security.logintracker.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String loginPage(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout,
            @RequestParam(value = "remaining", required = false, defaultValue = "0") int remaining,
            @RequestParam(value = "minutes", required = false, defaultValue = "0") long minutes,
            Model model) {

        if (error != null) {
            switch (error) {
                case "locked" -> {
                    model.addAttribute("errorType", "locked");
                    model.addAttribute("errorMessage",
                            "Your account has been locked due to too many failed login attempts.");
                    model.addAttribute("minutes", minutes);
                }
                case "invalid" -> {
                    model.addAttribute("errorType", "invalid");
                    model.addAttribute("errorMessage", "Invalid username or password.");
                    model.addAttribute("remaining", remaining);
                }
                case "disabled" -> {
                    model.addAttribute("errorType", "disabled");
                    model.addAttribute("errorMessage",
                            "Your account has been disabled. Please contact an administrator.");
                }
                default -> {
                    model.addAttribute("errorType", "error");
                    model.addAttribute("errorMessage",
                            "Authentication failed. Please try again.");
                }
            }
        }

        if (logout != null) {
            model.addAttribute("logoutMessage", "You have been successfully logged out.");
        }

        return "login";
    }
}
