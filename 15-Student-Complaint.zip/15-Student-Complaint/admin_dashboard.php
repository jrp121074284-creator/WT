<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "complaint_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (!isset($_SESSION['admin'])) {
    echo "Admin login required";
    exit();
}

// Join query
$sql = "
    SELECT complaints.id, students.username, complaints.complaint
    FROM complaints
    JOIN students ON complaints.student_id = students.id
";

$result = mysqli_query($conn, $sql);
?>

<h2>All Complaints</h2>

<table border="1" cellpadding="10">
<tr>
    <th>ID</th>
    <th>Student</th>
    <th>Complaint</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['complaint']; ?></td>
</tr>
<?php } ?>

</table>