CREATE DATABASE complaint_db;

USE complaint_db;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(50)
);

CREATE TABLE complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    complaint TEXT
);

INSERT INTO students(username,password) VALUES('student','123');