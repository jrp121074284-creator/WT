<?php
session_start();

if (isset($_POST['login'])) {

    $user = $_POST['user'];
    $pass = $_POST['pass'];

    // Hardcoded admin
    if ($user == "admin" && $pass == "admin") {
        $_SESSION['admin'] = true;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "Invalid Admin Login";
    }
}
?>

<h2>Admin Login</h2>

<form method="POST">
    Username: <input name="user"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <button name="login">Login</button>
</form>