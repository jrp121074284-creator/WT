<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "complaint_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['login'])) {

    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM students WHERE username='$user' AND password='$pass'";
    $res = mysqli_query($conn, $sql);

    if (mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
        $_SESSION['student_id'] = $row['id'];

        header("Location: complaint.php");
        exit();
    } else {
        echo "Invalid Login";
    }
}
?>

<h2>Student Login</h2>

<form method="POST">
    Username: <input name="user"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <button name="login">Login</button>
</form>