<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "complaint_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (!isset($_SESSION['student_id'])) {
    echo "Login first";
    exit();
}

if (isset($_POST['submit'])) {

    $complaint = $_POST['complaint'];
    $sid = $_SESSION['student_id'];

    $sql = "INSERT INTO complaints(student_id, complaint)
            VALUES('$sid','$complaint')";
    mysqli_query($conn, $sql);

    echo "Complaint Submitted";
}
?>

<h2>Submit Complaint</h2>

<form method="POST">
    <textarea name="complaint" required></textarea><br><br>
    <button name="submit">Submit</button>
</form>