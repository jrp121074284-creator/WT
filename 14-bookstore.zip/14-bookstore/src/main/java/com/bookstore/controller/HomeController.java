package com.bookstore.controller;

import com.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @Autowired
    private BookService bookService;

    @GetMapping({"/", "/home"})
    public String home(Model model) {
        model.addAttribute("featuredBooks", bookService.getFeaturedBooks());
        model.addAttribute("topRatedBooks", bookService.getTopRatedBooks());
        model.addAttribute("categories", bookService.getAllCategories());
        return "home";
    }
}
