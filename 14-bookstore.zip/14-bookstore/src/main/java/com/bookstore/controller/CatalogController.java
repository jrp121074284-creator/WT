package com.bookstore.controller;

import com.bookstore.model.Book;
import com.bookstore.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class CatalogController {

    @Autowired
    private BookService bookService;

    @GetMapping("/catalog")
    public String catalog(@RequestParam(value = "category", required = false) String category,
                          @RequestParam(value = "search", required = false) String search,
                          Model model) {

        List<Book> books;

        if (search != null && !search.trim().isEmpty()) {
            books = bookService.searchBooks(search.trim());
            model.addAttribute("searchQuery", search);
        } else if (category != null && !category.trim().isEmpty()) {
            books = bookService.getBooksByCategory(category);
            model.addAttribute("selectedCategory", category);
        } else {
            books = bookService.getAllBooks();
        }

        model.addAttribute("books", books);
        model.addAttribute("categories", bookService.getAllCategories());
        model.addAttribute("totalBooks", books.size());
        return "catalog";
    }

    @GetMapping("/catalog/{id}")
    public String bookDetail(@PathVariable Long id, Model model) {
        Book book = bookService.getBookById(id)
            .orElseThrow(() -> new RuntimeException("Book not found"));
        List<Book> relatedBooks = bookService.getRelatedBooks(book.getCategory(), id);
        model.addAttribute("book", book);
        model.addAttribute("relatedBooks", relatedBooks.stream().limit(4).toList());
        return "book-detail";
    }

    @GetMapping("/search")
    public String search(@RequestParam("q") String query, Model model) {
        return "redirect:/catalog?search=" + query;
    }
}
