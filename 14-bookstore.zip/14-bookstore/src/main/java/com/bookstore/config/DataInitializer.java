package com.bookstore.config;

import com.bookstore.model.Book;
import com.bookstore.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private BookRepository bookRepository;

    @Override
    public void run(String... args) throws Exception {
        if (bookRepository.count() == 0) {
            List<Book> books = Arrays.asList(
                createBook("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565",
                    "14.99", "19.99", "Fiction",
                    "A story of the fabulously wealthy Jay Gatsby and his love for the beautiful Daisy Buchanan.",
                    "https://covers.openlibrary.org/b/id/8432459-L.jpg", 4.2, 1842, true, "Scribner", 180),

                createBook("To Kill a Mockingbird", "Harper Lee", "9780061935466",
                    "13.99", "17.99", "Fiction",
                    "The unforgettable novel of a childhood in a sleepy Southern town and the crisis of conscience that rocked it.",
                    "https://covers.openlibrary.org/b/id/8228691-L.jpg", 4.8, 5231, true, "HarperCollins", 336),

                createBook("1984", "George Orwell", "9780451524935",
                    "12.99", "15.99", "Science Fiction",
                    "A dystopian social science fiction novel and cautionary tale about the dangers of totalitarianism.",
                    "https://covers.openlibrary.org/b/id/8575708-L.jpg", 4.7, 4892, true, "Signet Classic", 328),

                createBook("The Hobbit", "J.R.R. Tolkien", "9780547928227",
                    "15.99", "22.99", "Fantasy",
                    "A fantasy novel about the adventures of hobbit Bilbo Baggins, who embarks on an unexpected quest.",
                    "https://covers.openlibrary.org/b/id/8406786-L.jpg", 4.9, 7123, true, "Houghton Mifflin", 310),

                createBook("Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "9780439708180",
                    "10.99", "14.99", "Fantasy",
                    "The story of Harry Potter, an orphan who discovers he is a wizard and begins his education at Hogwarts.",
                    "https://covers.openlibrary.org/b/id/10110415-L.jpg", 4.9, 9871, true, "Scholastic", 309),

                createBook("The Alchemist", "Paulo Coelho", "9780062315007",
                    "13.99", "18.99", "Fiction",
                    "A philosophical novel about a young Andalusian shepherd and his journey to the pyramids of Egypt.",
                    "https://covers.openlibrary.org/b/id/8241352-L.jpg", 4.6, 6342, true, "HarperOne", 208),

                createBook("Sapiens: A Brief History of Humankind", "Yuval Noah Harari", "9780062316097",
                    "17.99", "24.99", "Non-Fiction",
                    "A survey of the history of humankind from the evolution of archaic human species to the 21st century.",
                    "https://covers.openlibrary.org/b/id/8739161-L.jpg", 4.5, 3421, true, "Harper", 443),

                createBook("Atomic Habits", "James Clear", "9780735211292",
                    "19.99", "27.99", "Self-Help",
                    "An Easy & Proven Way to Build Good Habits & Break Bad Ones.",
                    "https://covers.openlibrary.org/b/id/10519447-L.jpg", 4.8, 5678, true, "Avery", 320),

                createBook("The Catcher in the Rye", "J.D. Salinger", "9780316769174",
                    "12.99", "16.99", "Fiction",
                    "The story of Holden Caulfield, a cynical teenager narrating the events of a few days following his expulsion.",
                    "https://covers.openlibrary.org/b/id/8231432-L.jpg", 4.1, 2134, false, "Little, Brown", 277),

                createBook("Dune", "Frank Herbert", "9780441013593",
                    "16.99", "22.99", "Science Fiction",
                    "A science fiction novel about the desert planet Arrakis, the only source of the universe's most precious substance.",
                    "https://covers.openlibrary.org/b/id/8260191-L.jpg", 4.7, 4231, false, "Ace", 896),

                createBook("The Da Vinci Code", "Dan Brown", "9780307474278",
                    "14.99", "20.99", "Mystery",
                    "A mystery thriller novel that follows symbologist Robert Langdon and cryptologist Sophie Neveu.",
                    "https://covers.openlibrary.org/b/id/8389945-L.jpg", 4.0, 8934, false, "Anchor", 689),

                createBook("Gone Girl", "Gillian Flynn", "9780307588371",
                    "13.99", "17.99", "Mystery",
                    "A psychological thriller about the sudden disappearance of Amy Dunne on her fifth wedding anniversary.",
                    "https://covers.openlibrary.org/b/id/8391451-L.jpg", 4.2, 3218, false, "Crown", 422),

                createBook("The Power of Now", "Eckhart Tolle", "9781577314806",
                    "15.99", "19.99", "Self-Help",
                    "A guide to spiritual enlightenment about living in the present moment.",
                    "https://covers.openlibrary.org/b/id/8412631-L.jpg", 4.4, 2897, false, "New World Library", 236),

                createBook("Educated", "Tara Westover", "9780399590504",
                    "16.99", "22.99", "Biography",
                    "A memoir about a woman who grows up in a survivalist family and strives for education.",
                    "https://covers.openlibrary.org/b/id/8723951-L.jpg", 4.7, 4521, false, "Random House", 334),

                createBook("The Lean Startup", "Eric Ries", "9780307887894",
                    "18.99", "26.99", "Business",
                    "How Today's Entrepreneurs Use Continuous Innovation to Create Radically Successful Businesses.",
                    "https://covers.openlibrary.org/b/id/8391462-L.jpg", 4.3, 1987, false, "Crown Business", 336),

                createBook("Thinking, Fast and Slow", "Daniel Kahneman", "9780374533557",
                    "17.99", "24.99", "Non-Fiction",
                    "Explores the two systems that drive the way we think: System 1 (fast) and System 2 (slow).",
                    "https://covers.openlibrary.org/b/id/8391470-L.jpg", 4.6, 3142, false, "Farrar, Straus and Giroux", 499)
            );
            bookRepository.saveAll(books);
            System.out.println("✅ Sample books loaded successfully!");
        }
    }

    private Book createBook(String title, String author, String isbn,
                             String price, String originalPrice, String category,
                             String description, String imageUrl, double rating,
                             int reviewCount, boolean featured, String publisher, int pages) {
        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);
        book.setPrice(new BigDecimal(price));
        book.setOriginalPrice(new BigDecimal(originalPrice));
        book.setCategory(category);
        book.setDescription(description);
        book.setImageUrl(imageUrl);
        book.setRating(rating);
        book.setReviewCount(reviewCount);
        book.setFeatured(featured);
        book.setPublisher(publisher);
        book.setPages(pages);
        book.setStockQuantity(50);
        book.setLanguage("English");
        return book;
    }
}
