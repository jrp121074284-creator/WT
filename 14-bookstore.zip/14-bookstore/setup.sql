-- ================================================
-- PageTurner Bookstore — MySQL Setup Script
-- Run this BEFORE starting the application
-- ================================================

-- 1. Create the database
CREATE DATABASE IF NOT EXISTS bookstore_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- 2. Use the database
USE bookstore_db;

-- 3. (Optional) Create a dedicated user instead of using root
-- Uncomment and modify if you want a separate DB user:
-- CREATE USER 'bookstore_user'@'localhost' IDENTIFIED BY 'bookstore_pass';
-- GRANT ALL PRIVILEGES ON bookstore_db.* TO 'bookstore_user'@'localhost';
-- FLUSH PRIVILEGES;

-- ================================================
-- Tables are auto-created by Spring Boot JPA
-- (spring.jpa.hibernate.ddl-auto=update)
-- Sample data is loaded by DataInitializer.java
-- ================================================

-- To verify after running the app, check:
-- SELECT COUNT(*) FROM books;    -- Should be 16
-- SELECT COUNT(*) FROM users;    -- Grows as you register
