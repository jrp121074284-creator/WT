# 📚 PageTurner — Online Bookstore

A full-stack Spring Boot + MySQL web application with Home, Login, Registration, and Catalog pages.

---

## 🗂️ Project Structure

```
bookstore/
├── src/main/java/com/bookstore/
│   ├── BookstoreApplication.java        ← Main entry point
│   ├── config/
│   │   ├── SecurityConfig.java          ← Spring Security setup
│   │   └── DataInitializer.java         ← Seeds 16 sample books
│   ├── controller/
│   │   ├── HomeController.java          ← GET /
│   │   ├── AuthController.java          ← GET/POST /login, /register
│   │   └── CatalogController.java       ← GET /catalog, /catalog/{id}
│   ├── model/
│   │   ├── User.java                    ← users table entity
│   │   └── Book.java                    ← books table entity
│   ├── repository/
│   │   ├── UserRepository.java
│   │   └── BookRepository.java
│   └── service/
│       ├── UserService.java
│       ├── BookService.java
│       └── CustomUserDetailsService.java
├── src/main/resources/
│   ├── templates/
│   │   ├── home.html                    ← Home page
│   │   ├── login.html                   ← Login page
│   │   ├── register.html                ← Registration page
│   │   ├── catalog.html                 ← Catalog page
│   │   ├── book-detail.html             ← Book detail page
│   │   └── fragments/layout.html        ← Shared navbar + footer
│   ├── static/
│   │   ├── css/style.css
│   │   └── js/main.js
│   └── application.properties           ← ⚠️ EDIT THIS FILE
├── setup.sql                            ← Run this in MySQL first
└── pom.xml
```

---

## ✅ Prerequisites

| Tool | Version | Download |
|------|---------|----------|
| Java | 17+ | https://adoptium.net |
| Maven | 3.8+ | https://maven.apache.org |
| MySQL | 8.0+ | https://dev.mysql.com/downloads |

---

## 🚀 How to Run (Step-by-Step)

### Step 1 — Set Up MySQL Database

Open **MySQL Workbench** or **MySQL CLI** and run:

```sql
CREATE DATABASE IF NOT EXISTS bookstore_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
```

Or just run the provided script:
```bash
mysql -u root -p < setup.sql
```

---

### Step 2 — Configure Database Credentials

Open: `src/main/resources/application.properties`

Change these two lines to match your MySQL setup:

```properties
spring.datasource.username=root
spring.datasource.password=your_mysql_password_here
```

**Common variations:**
- If your root has no password: `spring.datasource.password=`
- If you created a custom user: use that username/password
- If MySQL is on a different port: `spring.datasource.url=jdbc:mysql://localhost:3307/bookstore_db?...`

---

### Step 3 — Build and Run

```bash
# Navigate to the project folder
cd bookstore

# Option A: Using Maven Wrapper (recommended)
./mvnw spring-boot:run          # Linux/Mac
mvnw.cmd spring-boot:run        # Windows

# Option B: Using system Maven
mvn spring-boot:run

# Option C: Build JAR and run
mvn clean package -DskipTests
java -jar target/bookstore-1.0.0.jar
```

---

### Step 4 — Open in Browser

Visit: **http://localhost:8080**

The app will auto-create tables and seed 16 sample books on first launch.

---

## 📄 Pages

| URL | Description |
|-----|-------------|
| http://localhost:8080/ | Home page with featured & top-rated books |
| http://localhost:8080/catalog | Book catalog with search & category filter |
| http://localhost:8080/catalog/{id} | Individual book detail page |
| http://localhost:8080/login | Login page |
| http://localhost:8080/register | Registration page |
| http://localhost:8080/logout | Logs out the current user |

---

## 🗄️ Database Tables

Tables are auto-created by Hibernate (`ddl-auto=update`).

### `users` table
| Column | Type | Notes |
|--------|------|-------|
| id | BIGINT (PK) | Auto-increment |
| first_name | VARCHAR | Required |
| last_name | VARCHAR | Required |
| email | VARCHAR | Unique |
| password | VARCHAR | BCrypt hashed |
| phone | VARCHAR | Optional |
| address | VARCHAR | Optional |
| role | VARCHAR | Default: "USER" |
| created_at | DATETIME | Auto-set |

### `books` table
| Column | Type | Notes |
|--------|------|-------|
| id | BIGINT (PK) | Auto-increment |
| title | VARCHAR | Required |
| author | VARCHAR | Required |
| isbn | VARCHAR | Unique |
| price | DECIMAL | Required |
| original_price | DECIMAL | For discount % |
| description | TEXT | |
| category | VARCHAR | |
| image_url | VARCHAR | |
| stock_quantity | INT | |
| rating | DOUBLE | |
| review_count | INT | |
| featured | BOOLEAN | Home page display |
| publisher | VARCHAR | |
| pages | INT | |
| language | VARCHAR | |

---

## 🔧 Common Issues & Fixes

### ❌ "Access denied for user 'root'@'localhost'"
→ Wrong password in `application.properties`. Update `spring.datasource.password`

### ❌ "Unknown database 'bookstore_db'"
→ Create the database first:
```sql
CREATE DATABASE bookstore_db;
```

### ❌ Port 8080 already in use
→ Change the port in `application.properties`:
```properties
server.port=8081
```

### ❌ "Could not autowire. No beans of type..."
→ Make sure all files are in the correct package `com.bookstore.*`

### ❌ Books not loading (images broken)
→ This is normal in offline environments. Book covers are loaded from openlibrary.org — needs internet access.

---

## 🔐 Security Notes

- Passwords are hashed with **BCrypt** (never stored in plain text)
- Spring Security handles login/logout sessions
- All `/catalog` and home pages are publicly accessible
- CSRF is disabled for simplicity (can be re-enabled for production)

---

## 🛠️ Customization Guide

### Change the store name
Search and replace `PageTurner` in HTML templates.

### Add more books
Edit `DataInitializer.java` — add more entries to the `books` list.

### Add an Admin role
- Set `user.setRole("ADMIN")` in `UserService`
- Add admin-only routes in `SecurityConfig.java`

### Connect to a remote MySQL
Change the URL in `application.properties`:
```properties
spring.datasource.url=jdbc:mysql://your-remote-host:3306/bookstore_db?...
```

---

*Built with Spring Boot 3.2, Thymeleaf, Spring Security, Spring Data JPA, MySQL*
