@echo off
setlocal

set "WRAPPER_JAR=.mvn\wrapper\maven-wrapper.jar"
set "MAVEN_OPTS=-Xmx1024m"

if not exist "%WRAPPER_JAR%" (
    echo Cannot find %WRAPPER_JAR%
    exit /b 1
)

java -classpath "%WRAPPER_JAR%" "-Dmaven.multiModuleProjectDirectory=%CD%" org.apache.maven.wrapper.MavenWrapperMain %*
