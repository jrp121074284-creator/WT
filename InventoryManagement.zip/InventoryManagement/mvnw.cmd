@REM -----------------------------------------------------------------------------
@REM Maven Wrapper Script for Windows
@REM -----------------------------------------------------------------------------

@IF "%__MVNW_ARG0_NAME__%"=="" (SET __MVNW_ARG0_NAME__=%~nx0)
@SET __MVNW_CMD__=
@SET __MVNW_ERROR__=
@SET __MVNW_PSMODULEP_SAVE=%PSModulePath%
@SET PSModulePath=
@FOR /F "usebackq tokens=1* delims==" %%A IN (`powershell -noprofile "& {$scriptDir='%~dp0'; $script='%__MVNW_ARG0_NAME__%'; $scriptDir=$scriptDir -replace '\\', '/'; $script=$script -replace '\\', '/'; $ErrorActionPreference='Stop'; iex ((Get-Content -Raw '%~f0') -replace '@REM Dummy placeholder to support PowerShell 2.0', '' -replace '\^<\^#\#\^>\^', '' -replace '\^<\^#\#\^>\^', '')}"`) DO @(
  IF "%%A"=="TRG" SET __MVNW_CMD__=%%B
)
@SET PSModulePath=%__MVNW_PSMODULEP_SAVE%
@SET __MVNW_PSMODULEP_SAVE=
@SET __MVNW_ARG0_NAME__=
@SET __MVNW_ERROR__=
@IF NOT "%__MVNW_CMD__%"=="" (%__MVNW_CMD__% %*)
@echo Cannot find maven-wrapper.jar
@exit /b 1
@GOTO :EOF
