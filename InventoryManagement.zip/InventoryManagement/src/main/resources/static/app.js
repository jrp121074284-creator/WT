const API_URL = '/api/products';
let allProducts = [];

// Load products on page load
document.addEventListener('DOMContentLoaded', loadProducts);

// Form submission
document.getElementById('productForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    await saveProduct();
});

async function loadProducts() {
    try {
        const response = await fetch(API_URL);
        allProducts = await response.json();
        displayProducts(allProducts);
        updateStats();
        updateCategoryFilter();
    } catch (error) {
        console.error('Error loading products:', error);
        alert('Failed to load products');
    }
}

function displayProducts(products) {
    const tbody = document.getElementById('productTableBody');
    tbody.innerHTML = '';

    if (products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="no-data">No products found</td></tr>';
        return;
    }

    products.forEach(product => {
        const row = document.createElement('tr');
        const quantityClass = product.quantity < 10 ? 'low-stock' : '';
        
        row.innerHTML = `
            <td>${product.name}</td>
            <td>${product.sku}</td>
            <td>${product.category}</td>
            <td>$${product.price}</td>
            <td class="${quantityClass}">${product.quantity}</td>
            <td class="action-buttons">
                <button onclick="editProduct('${product.id}')" class="btn btn-secondary">Edit</button>
                <button onclick="deleteProduct('${product.id}')" class="btn btn-danger">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function updateStats() {
    document.getElementById('totalProducts').textContent = allProducts.length;
    document.getElementById('lowStockCount').textContent = 
        allProducts.filter(p => p.quantity < 10).length;
    
    const categories = [...new Set(allProducts.map(p => p.category))];
    document.getElementById('categoryCount').textContent = categories.length;
}

function updateCategoryFilter() {
    const select = document.getElementById('categoryFilter');
    const categories = [...new Set(allProducts.map(p => p.category))];
    
    select.innerHTML = '<option value="">All Categories</option>';
    categories.forEach(cat => {
        select.innerHTML += `<option value="${cat}">${cat}</option>`;
    });
}

function openModal(productId = null) {
    document.getElementById('productModal').style.display = 'block';
    document.getElementById('modalTitle').textContent = productId ? 'Edit Product' : 'Add Product';
    
    if (productId) {
        const product = allProducts.find(p => p.id === productId);
        if (product) {
            document.getElementById('productId').value = product.id;
            document.getElementById('name').value = product.name;
            document.getElementById('sku').value = product.sku;
            document.getElementById('category').value = product.category;
            document.getElementById('price').value = product.price;
            document.getElementById('quantity').value = product.quantity;
            document.getElementById('description').value = product.description || '';
        }
    } else {
        document.getElementById('productForm').reset();
        document.getElementById('productId').value = '';
    }
}

function closeModal() {
    document.getElementById('productModal').style.display = 'none';
}

async function saveProduct() {
    const productId = document.getElementById('productId').value;
    const product = {
        name: document.getElementById('name').value,
        sku: document.getElementById('sku').value,
        category: document.getElementById('category').value,
        price: parseFloat(document.getElementById('price').value),
        quantity: parseInt(document.getElementById('quantity').value),
        description: document.getElementById('description').value
    };

    try {
        const url = productId ? `${API_URL}/${productId}` : API_URL;
        const method = productId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(product)
        });

        if (response.ok) {
            closeModal();
            await loadProducts();
            alert(productId ? 'Product updated successfully!' : 'Product created successfully!');
        } else {
            alert('Failed to save product');
        }
    } catch (error) {
        console.error('Error saving product:', error);
        alert('Error saving product');
    }
}

async function editProduct(id) {
    openModal(id);
}

async function deleteProduct(id) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            await loadProducts();
            alert('Product deleted successfully!');
        } else {
            alert('Failed to delete product');
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        alert('Error deleting product');
    }
}

function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filtered = allProducts.filter(p => 
        p.name.toLowerCase().includes(searchTerm) ||
        p.sku.toLowerCase().includes(searchTerm) ||
        p.category.toLowerCase().includes(searchTerm)
    );
    displayProducts(filtered);
}

function filterByCategory() {
    const category = document.getElementById('categoryFilter').value;
    if (!category) {
        displayProducts(allProducts);
    } else {
        const filtered = allProducts.filter(p => p.category === category);
        displayProducts(filtered);
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('productModal');
    if (event.target === modal) {
        closeModal();
    }
}
