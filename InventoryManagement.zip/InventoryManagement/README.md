# Product Inventory Management System

A Spring Boot-based Product Inventory Management System using MongoDB as the database.

## Project Structure

```
InventoryManagement/
├── pom.xml
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── example/
│       │           └── inventorymanagement/
│       │               ├── InventoryManagementApplication.java
│       │               ├── controller/
│       │               │   └── ProductController.java
│       │               ├── model/
│       │               │   └── Product.java
│       │               └── repository/
│       │                   └── ProductRepository.java
│       └── resources/
│           └── application.properties
```

## Prerequisites

- Java 17 or higher
- Maven 3.6+
- MongoDB (local or cloud instance)

## MongoDB Setup

### Option 1: Local MongoDB
1. Install MongoDB Community Edition from https://www.mongodb.com/try/download/community
2. Start MongoDB service
3. Default connection URI: `mongodb://localhost:27017/inventory_db`

### Option 2: MongoDB Atlas (Cloud)
1. Create a free cluster at https://www.mongodb.com/cloud/atlas
2. Update `application.properties` with your connection string:
   ```
   spring.data.mongodb.uri=mongodb+srv://username:password@cluster.mongodb.net/inventory_db
   ```

## Running the Application

```bash
# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

## API Endpoints

### Basic CRUD Operations

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/products` | Create a new product |
| GET | `/api/products` | Get all products |
| GET | `/api/products/{id}` | Get product by ID |
| PUT | `/api/products/{id}` | Update product by ID |
| DELETE | `/api/products/{id}` | Delete product by ID |

### Additional Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products/category/{category}` | Get products by category |
| GET | `/api/products/search?name={name}` | Search products by name |
| GET | `/api/products/low-stock?threshold={value}` | Get products with low stock |

## Testing with Postman or Browser

### 1. Create a Product (POST)

**URL:** `http://localhost:8080/api/products`

**Headers:**
- `Content-Type: application/json`

**Request Body:**
```json
{
    "name": "Laptop",
    "description": "High-performance gaming laptop",
    "category": "Electronics",
    "price": 999.99,
    "quantity": 50,
    "sku": "LAPTOP-001"
}
```

### 2. Get All Products (GET)

**URL:** `http://localhost:8080/api/products`

### 3. Get Product by ID (GET)

**URL:** `http://localhost:8080/api/products/{id}`

Replace `{id}` with the actual product ID returned from the create operation.

### 4. Update Product (PUT)

**URL:** `http://localhost:8080/api/products/{id}`

**Headers:**
- `Content-Type: application/json`

**Request Body:**
```json
{
    "name": "Gaming Laptop",
    "description": "Updated description",
    "category": "Electronics",
    "price": 1099.99,
    "quantity": 45,
    "sku": "LAPTOP-001"
}
```

### 5. Delete Product (DELETE)

**URL:** `http://localhost:8080/api/products/{id}`

### 6. Search by Category (GET)

**URL:** `http://localhost:8080/api/products/category/Electronics`

### 7. Search by Name (GET)

**URL:** `http://localhost:8080/api/products/search?name=laptop`

### 8. Get Low Stock Products (GET)

**URL:** `http://localhost:8080/api/products/low-stock?threshold=10`

## Product Model Fields

| Field | Type | Description |
|-------|------|-------------|
| id | String | MongoDB auto-generated ID |
| name | String | Product name |
| description | String | Product description |
| category | String | Product category |
| price | BigDecimal | Product price |
| quantity | Integer | Available stock quantity |
| sku | String | Stock Keeping Unit (unique identifier) |
| createdAt | LocalDateTime | Creation timestamp |
| updatedAt | LocalDateTime | Last update timestamp |

## Testing Sample Data

Create multiple products for testing:

```json
{
    "name": "Wireless Mouse",
    "description": "Bluetooth wireless mouse",
    "category": "Accessories",
    "price": 29.99,
    "quantity": 100,
    "sku": "MOUSE-001"
}
```

```json
{
    "name": "Mechanical Keyboard",
    "description": "RGB mechanical keyboard",
    "category": "Accessories",
    "price": 79.99,
    "quantity": 5,
    "sku": "KEYBOARD-001"
}
```
