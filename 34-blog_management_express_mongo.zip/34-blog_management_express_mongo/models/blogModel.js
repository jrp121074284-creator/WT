const { getDB } = require("../config");

// CREATE
async function createBlog(data) {
  const db = getDB();

  // prevent duplicate blog_id
  const exists = await db.collection("blogs").findOne({ blog_id: data.blog_id });
  if (exists) {
    throw new Error("Blog ID already exists");
  }

  return db.collection("blogs").insertOne({
    blog_id: data.blog_id,
    title: data.title,
    content: data.content
  });
}

// READ
async function getBlogs() {
  const db = getDB();
  return db.collection("blogs").find().toArray();
}

// UPDATE using blog_id
async function updateBlog(blog_id, data) {
  const db = getDB();

  let updateFields = {};

  // check properly (IMPORTANT CHANGE)
  if ("title" in data && data.title.trim() !== "") {
    updateFields.title = data.title;
  }

  if ("content" in data && data.content.trim() !== "") {
    updateFields.content = data.content;
  }

  // 🚨 if nothing to update
  if (Object.keys(updateFields).length === 0) {
    return { matchedCount: 1, modifiedCount: 0 };
  }

  return db.collection("blogs").updateOne(
    { blog_id: blog_id },
    { $set: updateFields }
  );
}

// DELETE using blog_id
async function deleteBlog(blog_id) {
  const db = getDB();
  return db.collection("blogs").deleteOne({ blog_id: blog_id });
}

module.exports = { createBlog, getBlogs, updateBlog, deleteBlog };