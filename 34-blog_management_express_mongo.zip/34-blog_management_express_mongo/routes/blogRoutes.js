const express = require("express");
const router = express.Router();
const { create, read, update, remove } = require("../controllers/blogController");

router.post("/blogs", create);
router.get("/blogs", read);
router.put("/blogs/:id", update);
router.delete("/blogs/:id", remove);

module.exports = router;