const express = require("express");
const path = require("path");
const { connectDB } = require("./config");
require("dotenv").config();

const app = express();
connectDB();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ROUTES
app.use("/", require("./routes/blogRoutes"));

// VIEWS
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views/index.html"));
});

app.get("/manage", (req, res) => {
  res.sendFile(path.join(__dirname, "views/manage.html"));
});

app.get("/view", (req, res) => {
  res.sendFile(path.join(__dirname, "views/view.html"));
});

app.listen(process.env.PORT, () => {
  console.log("Server running at http://localhost:" + process.env.PORT);
});