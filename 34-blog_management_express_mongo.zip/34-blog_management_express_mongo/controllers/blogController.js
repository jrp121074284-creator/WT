const { createBlog, getBlogs, updateBlog, deleteBlog } = require("../models/blogModel");

// CREATE
async function create(req, res) {
  try {
    if (!req.body.blog_id || !req.body.title || !req.body.content) {
      return res.json({ message: "All fields required" });
    }

    await createBlog(req.body);
    res.json({ message: "Blog Created" });

  } catch (err) {
    res.json({ message: err.message });
  }
}

// READ
async function read(req, res) {
  const data = await getBlogs();
  res.json(data);
}

// UPDATE
async function update(req, res) {
  const result = await updateBlog(req.params.id, req.body);

  if (result.matchedCount === 0) {
    return res.json({ message: "Blog not found" });
  }

  if (result.modifiedCount === 0) {
    return res.json({ message: "Nothing to update" });
  }

  res.json({ message: "Blog Updated Successfully" });
}

// DELETE
async function remove(req, res) {
  const result = await deleteBlog(req.params.id);

  if (result.deletedCount === 0) {
    return res.json({ message: "Blog not found" });
  }

  res.json({ message: "Blog Deleted Successfully" });
}

module.exports = { create, read, update, remove };