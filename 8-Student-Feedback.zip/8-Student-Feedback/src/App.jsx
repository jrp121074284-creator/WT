import React, { useState, useRef } from "react";

function App() {

  const [name, setName] = useState("");
  const [feedback, setFeedback] = useState("");
  const [list, setList] = useState([]);

  const nameRef = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validation
    if (name === "" || feedback === "") {
      alert("All fields required");
      return;
    }

    // Add to list
    const newItem = {
      id: Date.now(),
      name,
      feedback
    };

    setList([...list, newItem]);

    // Clear fields
    setName("");
    setFeedback("");

    // useRef → focus back to name input
    nameRef.current.focus();
  };

  return (
    <div>

      <h2>Student Feedback Form</h2>

      <form onSubmit={handleSubmit}>

        <input
          type="text"
          placeholder="Enter Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          ref={nameRef}
        />

        <br /><br />

        <textarea
          placeholder="Enter Feedback"
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
        />

        <br /><br />

        <button type="submit">Submit</button>

      </form>

      <hr />

      <h3>Submitted Feedback</h3>

      <ul>
        {list.map((item) => (
          <li key={item.id}>
            <b>{item.name}</b>: {item.feedback}
          </li>
        ))}
      </ul>

    </div>
  );
}

export default App;