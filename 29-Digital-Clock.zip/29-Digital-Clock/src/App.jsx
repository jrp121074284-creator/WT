import React, { useState, useEffect } from "react";

function App() {

  // 2. Store current time
  const [time, setTime] = useState(new Date());

  // 5. Start/Stop control
  const [running, setRunning] = useState(true);

  // 3. Update every second
  useEffect(() => {
    if (running) {
      const interval = setInterval(() => {
        setTime(new Date());
      }, 1000);

      // cleanup
      return () => clearInterval(interval);
    }
  }, [running]);

  // 4. Format HH:MM:SS
  const formatTime = (t) => {
    return t.toLocaleTimeString();
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Digital Clock</h2>

      <h1>{formatTime(time)}</h1>

      {/* 5. Start / Stop Button */}
      <button onClick={() => setRunning(!running)}>
        {running ? "Stop" : "Start"}
      </button>
    </div>
  );
}

export default App;