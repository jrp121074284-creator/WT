package com.example.password_encryption_spring_mongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasswordEncryptionSpringMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
