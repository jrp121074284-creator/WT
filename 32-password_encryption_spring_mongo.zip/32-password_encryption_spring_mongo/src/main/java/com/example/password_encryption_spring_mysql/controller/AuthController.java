package com.example.password_encryption_spring_mysql.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.password_encryption_spring_mysql.entity.User;
import com.example.password_encryption_spring_mysql.service.UserService;

@Controller
public class AuthController {

    @Autowired
    private UserService service;

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(User user, Model model) {
        String msg = service.register(user);
        if (msg.equals("Registration Successful!")) {
            model.addAttribute("message", msg);
            return "result";
        } else {
            model.addAttribute("error", msg);
            return "register";
        }
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        Model model) {

        String msg = service.login(username, password);
        model.addAttribute("message", msg);
        return "result";
    }
}