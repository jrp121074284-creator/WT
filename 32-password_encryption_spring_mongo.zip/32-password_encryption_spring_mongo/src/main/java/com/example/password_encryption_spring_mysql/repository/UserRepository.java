package com.example.password_encryption_spring_mysql.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.password_encryption_spring_mysql.entity.User;
import java.util.Optional;

public interface UserRepository extends MongoRepository<User, String> {
    Optional<User> findByUsername(String username);
    boolean existsByUsername(String username);
}
