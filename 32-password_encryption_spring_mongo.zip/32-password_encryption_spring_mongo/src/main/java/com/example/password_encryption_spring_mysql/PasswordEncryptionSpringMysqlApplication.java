package com.example.password_encryption_spring_mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PasswordEncryptionSpringMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(PasswordEncryptionSpringMysqlApplication.class, args);
	}

}
