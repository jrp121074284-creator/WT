package com.example.password_encryption_spring_mysql.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.password_encryption_spring_mysql.entity.User;
import com.example.password_encryption_spring_mysql.repository.UserRepository;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder encoder;

    public String register(User user) {
        if (repo.existsByUsername(user.getUsername())) {
            return "Username already taken! Please choose a different username.";
        }
        user.setPassword(encoder.encode(user.getPassword()));
        repo.save(user);
        return "Registration Successful!";
    }

    public String login(String username, String password) {
        Optional<User> optionalUser = repo.findByUsername(username);

        if(optionalUser.isPresent()) {
            User user = optionalUser.get();
            if(encoder.matches(password, user.getPassword())) {
                return "Login Successful!";
            }
        }
        return "Invalid Credentials!";
    }
}