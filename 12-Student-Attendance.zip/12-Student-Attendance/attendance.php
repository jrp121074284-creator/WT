<?php
$conn = mysqli_connect("localhost", "root", "", "attendance_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {

    $date = date("Y-m-d");

    $students = mysqli_query($conn, "SELECT id FROM students");

    while ($s = mysqli_fetch_assoc($students)) {
        $id = $s['id'];

        $status = isset($_POST['attendance'][$id]) ? "Present" : "Absent";

        $sql = "INSERT INTO attendance(student_id, date, status)
                VALUES('$id','$date','$status')";
        mysqli_query($conn, $sql);
    }

    echo "Attendance Saved!";
}

$result = mysqli_query($conn, "SELECT * FROM students");
?>

<h2>Take Attendance</h2>

<form method="POST">

<table border="1" cellpadding="10">
<tr>
    <th>Roll No</th>
    <th>Name</th>
    <th>Present</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row['roll_no']; ?></td>
    <td><?php echo $row['name']; ?></td>

    <td>
        <input type="checkbox" name="attendance[<?php echo $row['id']; ?>]" value="Present">
    </td>
</tr>
<?php } ?>

</table>

<br>
<button name="submit">Submit Attendance</button>

</form>