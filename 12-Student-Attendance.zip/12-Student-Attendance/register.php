<?php
$conn = mysqli_connect("localhost", "root", "", "attendance_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $roll = $_POST['roll'];

    $sql = "INSERT INTO students(name, roll_no) VALUES('$name','$roll')";
    mysqli_query($conn, $sql);
}
?>

<h2>Student Registration</h2>

<form method="POST">
    Name: <input type="text" name="name" required><br><br>
    Roll No: <input type="text" name="roll" required><br><br>
    <button name="register">Register</button>
</form>