CREATE DATABASE flight_db;

USE flight_db;

CREATE TABLE seats (
    seat_no VARCHAR(5) PRIMARY KEY,
    status VARCHAR(10)
);

INSERT INTO seats VALUES
('A1','Available'),('A2','Available'),('A3','Available'),
('B1','Available'),('B2','Available'),('B3','Available'),
('C1','Available'),('C2','Available'),('C3','Available');