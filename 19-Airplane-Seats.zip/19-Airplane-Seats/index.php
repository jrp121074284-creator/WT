<?php
$conn = mysqli_connect("localhost", "root", "", "flight_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Book seat
if (isset($_GET['book'])) {
    $seat = $_GET['book'];

    $sql = "UPDATE seats SET status='Booked' WHERE seat_no='$seat'";
    mysqli_query($conn, $sql);

    header("Location: index.php");
    exit();
}

// Fetch seats
$sql = "SELECT * FROM seats";
$result = mysqli_query($conn, $sql);
?>

<h2>Airplane Seat Booking</h2>

<table border="1" cellpadding="20">

<?php
$seats = [];

while ($row = mysqli_fetch_assoc($result)) {
    $seats[$row['seat_no']] = $row['status'];
}

// Display in rows
$rows = ['A', 'B', 'C'];

foreach ($rows as $r) {
    echo "<tr>";
    for ($i = 1; $i <= 3; $i++) {
        $seat = $r . $i;
        echo "<td align='center'>";

        echo $seat . "<br>";

        if ($seats[$seat] == "Available") {
            echo "<a href='?book=$seat'>Book</a>";
        } else {
            echo "Booked";
        }

        echo "</td>";
    }
    echo "</tr>";
}
?>

</table>