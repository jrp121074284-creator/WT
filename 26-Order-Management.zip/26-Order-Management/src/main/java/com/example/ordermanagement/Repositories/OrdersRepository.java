package com.example.ordermanagement.Repositories;

import com.example.ordermanagement.Entities.Orders;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdersRepository extends JpaRepository<Orders, Long> {
}
