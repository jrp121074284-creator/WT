package com.example.ordermanagement.Services;

import com.example.ordermanagement.Entities.Orders;
import com.example.ordermanagement.Repositories.OrdersRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrdersService {

    private final OrdersRepository ordersRepository;

    public OrdersService(OrdersRepository ordersRepository) {
        this.ordersRepository = ordersRepository;
    }

    // GET ALL
    public List<Orders> getAllOrders() {
        return ordersRepository.findAll();
    }

    // GET BY ID
    public Orders getOrderById(Long id) {
        return ordersRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
    }

    // CREATE
    public Orders createOrder(Orders order) {
        return ordersRepository.save(order);
    }

    // UPDATE (PUT → full replace)
    public Orders updateOrder(Long id, Orders newOrder) {

        Orders existingOrder = ordersRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));

        existingOrder.setName(newOrder.getName());
        existingOrder.setUser_name(newOrder.getUser_name());
        existingOrder.setTotal_price(newOrder.getTotal_price());
        existingOrder.setQuantity(newOrder.getQuantity());

        return ordersRepository.save(existingOrder);
    }

    // DELETE
    public void deleteOrder(Long id) {

        if (!ordersRepository.existsById(id)) {
            throw new RuntimeException("Order not found with id: " + id);
        }

        ordersRepository.deleteById(id);
    }
}