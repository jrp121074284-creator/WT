const form = document.getElementById("orderForm");
const table = document.getElementById("ordersTable");

window.onload = loadOrders;

function loadOrders() {
    fetch("/orders")
        .then(res => res.json())
        .then(data => {
            table.innerHTML = "";

            data.forEach(order => {
                const row = `
                    <tr>
                        <td>${order.id}</td>
                        <td>${order.name}</td>
                        <td>${order.user_name}</td>
                        <td>${order.total_price}</td>
                        <td>${order.quantity}</td>
                        <td>
                            <button onclick="editOrder(${order.id})">Edit</button>
                            <button onclick="deleteOrder(${order.id})">Delete</button>
                        </td>
                    </tr>
                `;
                table.innerHTML += row;
            });
        });
}

form.addEventListener("submit", function(e) {
    e.preventDefault();

    const id = document.getElementById("orderId").value;

    const order = {
        name: document.getElementById("name").value,
        user_name: document.getElementById("user_name").value,
        total_price: document.getElementById("price").value,
        quantity: document.getElementById("quantity").value
    };

    if (id) {
        fetch(`/orders/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(order)
        })
        .then(() => {
            resetForm();
            loadOrders();
        });
    }
    else {
        fetch("/orders", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(order)
        })
        .then(() => {
            resetForm();
            loadOrders();
        });
    }
});

function editOrder(id) {
    fetch(`/orders/${id}`)
        .then(res => res.json())
        .then(order => {
            document.getElementById("orderId").value = order.id;
            document.getElementById("name").value = order.name;
            document.getElementById("user_name").value = order.user_name;
            document.getElementById("price").value = order.total_price;
            document.getElementById("quantity").value = order.quantity;
        });
}

function deleteOrder(id) {
    fetch(`/orders/${id}`, {
        method: "DELETE"
    })
    .then(() => loadOrders());
}

function getOrderById() {
    const id = document.getElementById("searchId").value;

    fetch(`/orders/${id}`)
        .then(res => res.json())
        .then(order => {
            alert(`Order Found:
ID: ${order.id}
Name: ${order.name}
User: ${order.user_name}`);
        })
        .catch(() => alert("Order not found"));
}

function resetForm() {
    form.reset();
    document.getElementById("orderId").value = "";
}