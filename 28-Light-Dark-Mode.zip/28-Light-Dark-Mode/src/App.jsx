import React, { useState } from "react";

function App() {

  // 1. Store theme in state
  const [theme, setTheme] = useState("light");

  // 2. Toggle function
  const toggleTheme = () => {
    if (theme === "light") {
      setTheme("dark");
    } else {
      setTheme("light");
    }
  };

  // 3. Dynamic styles
  const style = {
    backgroundColor: theme === "light" ? "white" : "black",
    color: theme === "light" ? "black" : "white",
    height: "100vh",
    textAlign: "center",
    paddingTop: "50px"
  };

  return (
    <div style={style}>
      <h2>Theme Toggle App</h2>

      {/* 4. Display current mode */}
      <h3>Current Mode: {theme}</h3>

      {/* 1. Toggle button */}
      <button onClick={toggleTheme}>
        Toggle Theme
      </button>
    </div>
  );
}

export default App;